var fs = require('fs');
const path = require('path');

var i_max = 0;

const directoryPath = path.join(__dirname, '');

console.log(directoryPath);

try{
  fs.mkdirSync('monDossier');
} catch (err) {

  try {
  fs.mkdirSync('monDossier-0');
     console.log('monDossier-0 a été bien créer ') ;

  } catch (err) {
  fs.readdir(directoryPath, function (err, files) {
      if (err) {
          return console.log('Unable to scan directory: ' + err);
      }
      files.forEach(function (file) {
          if(file.includes('monDossier')){

            var number_folder = file.split('-');

            var number_i = parseInt(number_folder[1]);

            i_max = number_i;


          }
      });

      i_max = i_max + 1;

      fs.mkdirSync('monDossier-'+i_max);
      console.error('monDossier nommé dossier-',i_max);
  });
  }
}


