const exercice_2 = require('./exercice_2');

test('return 1', () => {
  expect(exercice_2(["Le Lorem Ipsum", "Le Lorem Ipsum est le faux texte standard de l'imprimerie", "BMW"])).toBe(1);
});
