var i = 0;
function exercice_2(strings) {
    strings.forEach(function (element) {
        if (element.length > 50) {
            i++;
        }
    });
    return i;
}
module.exports = exercice_2;
